<?php

class WPBakeryShortCode_VC_Gitem_Post_Meta extends WPBakeryShortCode {
}