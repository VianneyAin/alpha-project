<?php
//-- Notification Bar Setting Option ------------------------------------------
//-----------------------------------------------------------------------------
function settings_notification_bar(){
	global $nbar_message; 
    global $wpdb;
	$table_name = $wpdb->prefix . "notificationbar"; 
    $nbar_data = $wpdb->get_results("SELECT * FROM $table_name where active='1' ORDER BY id DESC");
	$nbar_getOpts = get_option('notificationbar_settings');
	
	if (array_key_exists("nbar_settingchk",$nbar_getOpts)) {
		$nbar_getOpts['nbar_settingchk'] = $nbar_getOpts['nbar_settingchk'];
	}else{
		$nbar_getOpts['nbar_settingchk'] = 0;
	}
?>
	
	<form class="nbar_editform" id="nbar_settfrm" name="nbar_settings" method="post" action="">
		<div class="nbpro_extmsg_chk" style="margin: 0 0 -5px 0px;"><label class="nbpro_mkchk <?php if($nbar_getOpts['nbar_settingchk']){ ?>checked<?php } ?>" for="nbar_settchk"></label><input type="checkbox" class="nbpro_chkbox" id="nbar_settchk"  name="notificationbar_settings[nbar_settingchk]" <?php if($nbar_getOpts['nbar_settingchk']){ ?> checked <?php } ?> value="true"/> <?php _e('Enable "Global Notification Bar" ','nbar'); ?></div>
		<div class="nbpro_extendbox nbar_setblock" style="margin-left:0px;<?php if($nbar_getOpts['nbar_settingchk']){ ?>display:block;<?php }else{ ?>display:none;<?php } ?>">
			<div class="nbpro_topbdr"></div>
			<div class="nbpro_midbdr">
				<div class="nbar_setting">
					<table style="width: 100%" class="nbar_settbl" cellpadding="9" >
						<tr>
							<td style="width: 170px !important;"><?php _e("Default Notification Bar:",'nbar'); ?></td>
							<td>
								<select name="notificationbar_settings[nbar_setDfltnbar]">
									<?php
									foreach ($nbar_data as $data) { 
									   ?><option  value="<?php echo $data->id; ?>" <?php if($nbar_getOpts['nbar_setDfltnbar'] == $data->id ){ echo 'selected="selected"'; }?>><?php echo $data->option_name; ?></option><?php
									}
									?>
								</select>
								<a class="nbar_tooltip" title="<?php _e('This Notification Bar will be used for all Posts,Pages and Categories until you have not selected in page/post editor.','nbar'); ?>"></a>
							</td>
						</tr>

						<tr><td colspan="2"><?php _e("Where to show Default Notification Bar:",'nbar'); ?></td></tr>
						<tr>
							<td colspan="2">
								<label for="nbar_pages" class="<?php if($nbar_getOpts['nbar_setPages']){ ?> checked <?php } ?>" ><input type="checkbox" class="nbpro_smallchkbox" name="notificationbar_settings[nbar_setPages]" id="nbar_pages" <?php if($nbar_getOpts['nbar_setPages']){ ?> checked <?php } ?> value="true" />&nbsp;<?php _e("Pages",'nbar'); ?></label>
								<label for="nbar_posts" class="<?php if($nbar_getOpts['nbar_setPosts']){ ?> checked <?php } ?>" ><input type="checkbox" class="nbpro_smallchkbox" name="notificationbar_settings[nbar_setPosts]" id="nbar_posts" <?php if($nbar_getOpts['nbar_setPosts']){ ?> checked <?php } ?> value="true" />&nbsp;<?php _e("Posts",'nbar'); ?></label>
								<label for="nbar_homep" class="<?php if($nbar_getOpts['nbar_setHomepage']){ ?> checked <?php } ?>" ><input type="checkbox" class="nbpro_smallchkbox" name="notificationbar_settings[nbar_setHomepage]" id="nbar_homep" <?php if($nbar_getOpts['nbar_setHomepage']){ ?> checked <?php } ?> value="true" />&nbsp;<?php _e("Home Page",'nbar'); ?></label>
								<label for="nbar_blogp" class="<?php if($nbar_getOpts['nbar_setBlogpage']){ ?> checked <?php } ?>" ><input type="checkbox" class="nbpro_smallchkbox" name="notificationbar_settings[nbar_setBlogpage]" id="nbar_blogp" <?php if($nbar_getOpts['nbar_setBlogpage']){ ?> checked <?php } ?> value="true" />&nbsp;<?php _e("Blog Page",'nbar'); ?></label>		
								<label for="nbar_catgs" class="<?php if($nbar_getOpts['nbar_setcats']){ ?> checked <?php } ?>" ><input type="checkbox" class="nbpro_smallchkbox" name="notificationbar_settings[nbar_setcats]" id="nbar_catgs" <?php if($nbar_getOpts['nbar_setcats']){ ?> checked <?php } ?> value="true" />&nbsp;<?php _e("Categories",'nbar'); ?></label>	
								<label for="nbar_ctaxs" class="<?php if($nbar_getOpts['nbar_setctax']){ ?> checked <?php } ?>" ><input type="checkbox" class="nbpro_smallchkbox" name="notificationbar_settings[nbar_setctax]" id="nbar_ctaxs" <?php if($nbar_getOpts['nbar_setctax']){ ?> checked <?php } ?> value="true" />&nbsp;<?php _e("Custom Taxonomies",'nbar'); ?></label>		
								<label for="nbar_tags"  class="<?php if($nbar_getOpts['nbar_settags']){ ?> checked <?php } ?>" ><input type="checkbox"  class="nbpro_smallchkbox" name="notificationbar_settings[nbar_settags]" id="nbar_tags" <?php if($nbar_getOpts['nbar_settags']){ ?> checked <?php } ?> value="true" />&nbsp;<?php _e("Tags",'nbar'); ?></label>		
								<label for="nbar_date"  class="<?php if($nbar_getOpts['nbar_setdate']){ ?> checked <?php } ?>" ><input type="checkbox"  class="nbpro_smallchkbox" name="notificationbar_settings[nbar_setdate]" id="nbar_date" <?php if($nbar_getOpts['nbar_setdate']){ ?> checked <?php } ?> value="true" />&nbsp;<?php _e("Date Archive",'nbar'); ?></label>													
								<label for="nbar_auth"  class="<?php if($nbar_getOpts['nbar_setauthor']){ ?> checked <?php } ?>" ><input type="checkbox"  class="nbpro_smallchkbox" name="notificationbar_settings[nbar_setauthor]" id="nbar_auth" <?php if($nbar_getOpts['nbar_setauthor']){ ?> checked <?php } ?> value="true" />&nbsp;<?php _e("Author Page",'nbar'); ?></label>													
							</td>                                             
						</tr>
					</table>
				</div>	
				<div class="nbpro_clear"></div>
			</div>
			<div class="nbpro_btmbdr"></div>
		</div>
		<p class="button-controls"><input type="submit" name="nbar_settingsave" value="Save Setting" style="margin-left: 10px;"></p>
	</form>
<?php
}

//-- Updated notification bar Settings ----------------------------------------
//-----------------------------------------------------------------------------
if(isset($_REQUEST['nbar_settingsave'])) {
    update_option('notificationbar_settings',nbar_updateSettings());
}

function nbar_updateSettings(){
		$nbar_settingOption = $_REQUEST['notificationbar_settings'];
	    $nbar_updateset = array(
		'nbar_settingchk' => $nbar_settingOption['nbar_settingchk'],
		'nbar_setDfltnbar' => $nbar_settingOption['nbar_setDfltnbar'],
		'nbar_setPages' => $nbar_settingOption['nbar_setPages'],
		'nbar_setPosts' => $nbar_settingOption['nbar_setPosts'],
		'nbar_setHomepage' => $nbar_settingOption['nbar_setHomepage'],
		'nbar_setBlogpage' => $nbar_settingOption['nbar_setBlogpage'],
		'nbar_setcats' => $nbar_settingOption['nbar_setcats'],
		'nbar_setctax' => $nbar_settingOption['nbar_setctax'],
		'nbar_settags' => $nbar_settingOption['nbar_settags'],
		'nbar_setdate' => $nbar_settingOption['nbar_setdate'],
		'nbar_setauthor' => $nbar_settingOption['nbar_setauthor']
	);
return $nbar_updateset;
}
?>