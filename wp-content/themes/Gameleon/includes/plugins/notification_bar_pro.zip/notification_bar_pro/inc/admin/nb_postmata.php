<?php

//-- Dispaly All Notification Bars in Post/Page Editor ------------------------
//-----------------------------------------------------------------------------
add_action("admin_menu", "nbar_post_meta_box_options");
add_action('save_post', 'nbar_post_meta_box_save');

function nbar_post_meta_box_options(){
	if( function_exists( 'add_meta_box' ) ) {
		$post_types=get_post_types(); 
		foreach($post_types as $post_type) {
			add_meta_box("nbar_post_metas", "Select Notification Bar for this page/post", "nbar_post_meta_box_add", $post_type, "normal", "high");
		}
	}
	else{
	}
}

function nbar_post_meta_box_add(){

	global $post;
	$custom = get_post_custom($post->ID);
	
	$nbar_disable   = (array_key_exists("nbar_disable",$custom)) ? $custom["nbar_disable"][0] : 0;
	$nbar_check     = (array_key_exists("nbar_check",$custom)) ? $custom["nbar_check"][0] : 0;
	$nbar_selection = (array_key_exists("nbar_selection",$custom)) ? $custom["nbar_selection"][0] : 0;

    global $wpdb;
	$table_name = $wpdb->prefix . "notificationbar"; 
    $nbar_data = $wpdb->get_results("SELECT * FROM $table_name where active='1' ORDER BY id DESC");

	?>

	<input type="checkbox" name="nbar_disable" id="nbar_disable" <?php if($nbar_disable){ ?> checked <?php } ?> value="true"/>&nbsp;<label for="nbar_disable" style="color:red;"><?php _e('Check this, if you want to disable Notification Bar for this post/page.','nbar'); ?> </label><br/>
	
	<input type="hidden" name="nabr_matasubmit" value="1" />
	
	<div class="nbar_disable">
	
		<div class="nbar_checkbox">
			<input type="checkbox" name="nbar_check" id="nbar_check" <?php if($nbar_check){ ?> checked <?php } ?> value="true"/>&nbsp;<label for="nbar_check"><?php _e('Add "Notification Bar" to this post/page..','nbar'); ?> </label>
		</div>
	
		<?php
		if($nbar_data){
				?><select name="nbar_selection" class="nbar_selection">
				<?php
				foreach ($nbar_data as $data) { 
				   ?><option  value="<?php echo $data->id; ?>" <?php if($nbar_selection == $data->id ){ echo 'selected="selected"'; }?>><?php echo $data->option_name; ?></option><?php
				}
				?></select><?php
			}
			else{
				?><span style="color:red"><?php _e("Notification Bar(s) not activated / created.",'nbar') ?></span><?php
			}
		?>
	</div><?php
}

//update post custom fields
function nbar_post_meta_box_save(){
	global $post;
	if(isset($_REQUEST['nabr_matasubmit'])) {
		update_post_meta($post->ID, "nbar_selection",$_POST['nbar_selection']);
		update_post_meta($post->ID, "nbar_disable",$_POST['nbar_disable']);
		update_post_meta($post->ID, "nbar_check",$_POST['nbar_check']);
	}
}
?>