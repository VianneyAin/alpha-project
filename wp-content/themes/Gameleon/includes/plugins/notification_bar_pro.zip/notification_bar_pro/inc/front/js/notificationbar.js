(function ($) {
    $.fn.notificationbar = function (options) {
        var defaults = {
            "defaultstate": "open",
            "staytime": "6000",
            "exmsgstate": "close",
			"exmsgopentm":"4000",
			"exmsgclosetm":"4000",
			"disablecmsg" : "no"
        };
        var options = $.extend(defaults, options);
        return this.each(function () {
            var opts = options;
            obj = $(this);
            objDwn = $(obj.find(".nbar_downArr").attr("href"));
            objPush = $(".notification_push");
            var stayTimer;
			var extmsgopen;
			var extmsgcounter;
			var extmsgclose;

			function clearAll(){
			    clearTimeout(stayTimer);
				clearTimeout(extmsgopen);
				clearTimeout(extmsgcounter);
				clearTimeout(extmsgclose);
				obj.find(".nbar_extendmsg .nbar_extinfo").remove();
			}
			
            function staytime() {
                stayTimer = setTimeout(function () {
                    obj.slideUp("fast");
                    objDwn.slideDown();
                    pullObj()
                }, opts.staytime)
            }
			
			function exmsgOpenClose(){
				extmsgopen = setTimeout(function(){
					obj.find(".nbar_extendmsg").slideDown('fast',function(){obj.find("a.nbar_plusminus").addClass("active");});
		
					if(opts.disablecmsg =="no"){
						obj.find(".nbar_extendmsg").append('<div class="nbar_extinfo">This Message will close in <span class="nbar_ctm"></span> Seconds.</div>');
						var nbarcounter = opts.exmsgclosetm / 1000;
						obj.find('.nbar_extinfo .nbar_ctm').text(nbarcounter-1);
						extmsgcounter = setInterval(function(){
							nbarcounter--;
							obj.find('.nbar_extinfo .nbar_ctm').text(nbarcounter);
						},1000);
					}
					
					extmsgclose = setTimeout(function(){
						obj.find(".nbar_extendmsg").slideUp('fast',function(){obj.find("a.nbar_plusminus").removeClass("active");});
						obj.find(".nbar_extendmsg .nbar_extinfo").remove();
					},opts.exmsgclosetm);
				},opts.exmsgopentm);
			}
			
            function pushObj() {
                var obj_pushHt = 1;
                objPush.css("height", obj_pushHt + 40);
                objPush.slideDown("fast")
            }
            function pullObj() {
                objPush.css("height", "");
                objPush.slideUp("fast")
            }
            if (opts.defaultstate == "open") {
                obj.slideDown("fast");
                pushObj();
                if (opts.exmsgstate == "open") {
					exmsgOpenClose();
                    staytime()
                } else staytime()
            } else if (opts.defaultstate == "close") {
                objDwn.show();
                if (opts.exmsgstate == "open") {
                    exmsgOpenClose();
                } else staytime()
            } else;
            obj.find("a.nbar_plusminus,.nbar_extclick").click(function () {
                clearAll();
                obj.find(".nbar_extendmsg").stop(true,true).slideToggle('fast',function(){$("a.nbar_plusminus").toggleClass("active");});
            });
			
			$(".nbar_extclick_shortcode").click(function () {
                clearAll();
				if($('#notificationbar:visible').length){
					obj.slideUp("fast");
					obj.find(".nbar_extendmsg").stop(true,true).slideUp();
					$("a.nbar_plusminus").removeClass("active");
					objDwn.slideDown();
					pullObj();
				}else{
					objDwn.hide();
					obj.slideDown("fast");
					obj.find(".nbar_extendmsg").stop(true,true).slideDown();
					$("a.nbar_plusminus").addClass("active");
					pushObj();
				}
                
                
            });
			
            obj.find("a.nbar_close").click(function () {
                clearAll();
                obj.slideUp("fast");
                objDwn.slideDown();
                pullObj()
            });
            objDwn.click(function () {
                $(this).hide();
				clearAll();
                obj.slideDown("fast");
                pushObj();
            });
			
			// close extend msg at "esc" button click event
			$(document).keyup(function(e){ 
				if (e.keyCode == 27) {
					obj.find(".nbar_extendmsg").slideUp('fast',function(){obj.find("a.nbar_plusminus").removeClass("active");});
				}
			});
        })
    }
})(jQuery);