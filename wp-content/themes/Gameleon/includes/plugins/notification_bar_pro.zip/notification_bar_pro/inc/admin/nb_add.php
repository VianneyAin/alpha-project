<?php
//-- Get all Notification Bars from Database ----------------------------------
//-----------------------------------------------------------------------------
function get_nbars()
{  
    global $wpdb;$num=1;
	$table_name = $wpdb->prefix . "notificationbar"; 
    $nbar_data = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id");
	?>
	<div class="nbpro_topbdr"></div>
	<div class="nbpro_midbdr">
		<table border="0" cellspacing="0" style="margin: 0 8px;width: 98%;">
			<tbody>
				<?php
				foreach ($nbar_data as $data) { 
					
					if($data->active == '1')
					{ $active='<a href="?page=notificationbar&nbar_deactivate='.$data->id.'" class="nbardeactive_button"></a>';
					  $disabled='';
					}
					else{
						if($data->active == '0'){
							$active='<a href="?page=notificationbar&nbar_activate='.$data->id.'" class="nbaractive_button"></a>';
							$disabled='disabled="disabled"';
							}
						}
					
					echo '<tr class="nbar_tr1"><td style=" width: 89px !important;">'.$data->id.'</td><td valign="middle" style="text-align: center;width: 217px !important;"> '.$data->option_name.' </td><td style="  padding-left: 29px;width: 90px !important;">
					<a href="?page=nbar_edit&edit='.$data->option_name.'" class="nbaredit_button" '.$disabled.'></a>        
					</td><td style="padding-left: 46px;width: 100px !important;"> '.$active.' </td>
					<td style="padding-left: 29px;"> <a href="?page=notificationbar&nbar_delete='.$data->option_name.'" onclick="return nbar_delconfirm(\''.$data->option_name.'\');" class="nbar_del"></a> </td></tr>';
					$num++;
				}
				?>
			</tbody>
		</table>	
		<div class="nbpro_clear"></div>
	</div>
	<div class="nbpro_btmbdr">
		<form method="post" action="?page=notificationbar&add=1">
		<table cellspacing="0" style="margin: 0 12px;width: 95%;">
		   <tr class="nbar_tr2"> 
			   <td><?php echo ($data->id+1); ?> </td>
			   <td><input class="large_text_box" type="text" id="nabr_option_name" name="nabr_option_name" size="23" />
			   <td><font style="font-size:10px;color:#A40B0B">&nbsp;&nbsp;<?php _e("* Do not use spaces or special characters.",'nbar'); ?></font></td>    
			   </td>
			   <td colspan="2"><input type="submit" style="margin-top: 2px;" value="" name="nbar_newadd" /></td>
		   </tr>
		</table>
	   </form>
	</div>
    <?php
}

//-- Add Notification Bar (Function) ------------------------------------------
//-----------------------------------------------------------------------------
function add_notification_bar()
{
?>
<div id="nbpro_wrapper">
	<div class="nbpro_head"><div class="nbpro_title"><div class="nbpro_title_txt"><?php _e('Pro ( Version '.nbar_get_version().' )','nbar'); ?></div></div></div>
	<div id="nbar_addwrap" class="nbpro_cont">
	
		<div class="nbpro_leftbox">
			<div class="nbpro_topbox">
				<a href="http://www.wpfruits.com/" title="wpfruits.com" target="_blank" class="nbpro_wpflogo"></a>
				<div class="nbpro_clear"></div>
			</div>
			
			<?php			
			//notificationbar Functions
			if(isset($_GET['add']) && isset($_POST['nbar_newadd']))
			{
				$option=$_POST['nabr_option_name'];
				if(!get_option($_POST['nabr_option_name']))
				{
				 if($option){
						$option = preg_replace('/[^a-z0-9\s]/i', '', $option);  
						$option = str_replace(" ", "_", $option);
						global $wpdb;
						$table_name = $wpdb->prefix . "notificationbar"; 
						 $options = get_option($option);
						if($options)
						{
							$nbar_message= 'Unable to Add Notification Bar, please try another name';
						}else{
							$sql = "INSERT INTO " . $table_name . " values ('','".$option."','1');";
							if ($wpdb->query( $sql )){
									add_option($option, nbar_defaults());
									$nbar_message= 'Notification Bar successfully added';
								}
							else{
									$nbar_message= 'Unable to Add Notification Bar, can not insert Notification Bar';
								}
							};
						}else{
								$nbar_message= 'Unable to Add Notification Bar';
							}
				}else{
					$nbar_message= 'Unable to Add Notification Bar, please try another name';
				}
				?>
			<div class="nabr_updated" id="nbar_message"><?php _e($nbar_message,'nbar'); ?></div>
			<?php
			}
			
			if(isset($_GET['nbar_delete']))
			{
				$option=$_GET['nbar_delete'];
				delete_option($option);
				global $wpdb;
				$table_name = $wpdb->prefix . "notificationbar"; 
				$sql = "DELETE FROM " . $table_name . " WHERE option_name='".$option."';";
				$wpdb->query( $sql );
			?>
			<div class="nabr_updated" id="nbar_message"><?php _e('Notification Bar Deleted','nbar'); ?></div>
			<?php
			}

			if(isset($_GET['nbar_deactivate'])){
				$id=$_GET['nbar_deactivate'];
				global $wpdb;
				$table_name = $wpdb->prefix . "notificationbar"; 
				$sql = "UPDATE " . $table_name . " SET active='0' WHERE id='".$id."';";
				$wpdb->query( $sql );
			?>
			<div class="nabr_updated" id="nbar_message"><?php _e('Notification Bar Deactivated','nbar'); ?></div>
			<?php
			}

			if(isset($_GET['nbar_activate'])){
				$id=$_GET['nbar_activate'];
				global $wpdb;
				$table_name = $wpdb->prefix . "notificationbar"; 
				$sql = "UPDATE " . $table_name . " SET active='1' WHERE id='".$id."';";
				$wpdb->query( $sql );
			?>
			<div class="nabr_updated" id="nbar_message"><?php _e('Notification Bar Activated','nbar'); ?></div>
			<?php
			}
			?>
			
			<div id="nbar_addwrap">
				<div class="nbpro_settings">
					<div class="nbpro_distxt"><?php _e('DEFAULT (GLOBAL) NB SETTINGS','nbar'); ?></div>
					<div class="nbpro_savebox"><a class="nbpro_plus_minus" href="Javascript:void(0);"></a><div class="nbpro_clear"></div></div><div class="nbpro_clear"></div>
				</div>
				<div class="nbpro_extendbox">
					<?php settings_notification_bar(); ?>
				</div>

				<div class="nbpro_settings">
					<div class="nbpro_distxt"><?php _e('TABLE OF NOTIFICATION BARS','nbar'); ?></div>
					<div class="nbpro_savebox"><a class="nbpro_plus_minus" href="Javascript:void(0);"></a><div class="nbpro_clear"></div></div><div class="nbpro_clear"></div>
				</div>
				<div class="nbpro_extendbox">
					<?php get_nbars(); ?>
				</div>
			</div>

		</div>
		<div class="nbpro_clear"></div>
	</div>
</div>
<?php
}
//-----------------------------------------------------------------------------
?>