<?php
function nbar_update() { 
	$nbarxml_url = 'http://www.sketchthemes.com/sketch-updates/plugin-updates/notification-bar-pro/notificationbar.xml';
	$nbarxml_txt = @simplexml_load_file($nbarxml_url);
	if($nbarxml_txt){
		$nbarxml_version = $nbarxml_txt->notificationbar[0]->version;
		$nbarxml_updates = $nbarxml_txt->notificationbar[0]->htmldata;
		$nbar_cur_version = nbar_get_version();
		if($nbar_cur_version < $nbarxml_version){ if($nbarxml_updates){ ?><div id="nbar_updates"><?php echo $nbarxml_updates; ?></div> <?php } } 
	}
}
// Now we set that function up to execute when the admin_notices action is called
add_action( 'admin_notices', 'nbar_update' );
?>