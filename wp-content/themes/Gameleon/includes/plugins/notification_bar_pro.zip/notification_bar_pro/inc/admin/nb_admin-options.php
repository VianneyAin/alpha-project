<?php
include_once('nb_add.php');
include_once('nb_edit.php');
include_once('nb_postmata.php');
include_once('nb_settings.php');
?>