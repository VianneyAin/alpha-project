<?php
// add styles to the corresponding notification bar
function nbar_addStyles($nbar_option){
$nbar_getOptCss = get_option($nbar_option);
$nbar = $nbar_getOptCss;
?>
<!-- Notification Bar PRO Starts Here -->
<style type="text/css">
#notificationbar{<?php echo $nbar['defaultposition']; ?>:0; <?php if($nbar['defaultposition'] =="bottom"){ ?>border-top:3px solid #fff;<?php }else{ ?> border-bottom:3px solid #fff;<?php } ?>}
#notificationbar,#nbar_downArr{background-color:<?php echo $nbar['colorScheme']; ?>;} 
#nbar_downArr{<?php echo $nbar['defaultposition']; ?>:-41px;<?php if($nbar['defaultposition'] =="bottom"){ ?> background-image:url("<?php echo plugins_url('',dirname(__FILE__)); ?>/images/up_arrow.png")!important ;<?php } ?>}
#notificationbar .nbar_topwrap .nbar_msg{font-size:<?php echo $nbar['messageFont']; ?>px;color:<?php echo $nbar['messageColor']; ?>; }
#notificationbar .nbar_topwrap .nbar_button{font-size:<?php echo $nbar['linkFont']; ?>px;color:<?php echo $nbar['linkTextColor']; ?>;background:<?php echo $nbar['linkBgcolor']; ?>}
#notificationbar .nbar_extendmsg .nbar_extendmsg_txt{font-size:<?php echo $nbar['extendMesgFont']; ?>px;color:<?php echo $nbar['extendMesgColor']; ?>; }
#notificationbar .nbar_extendmsg .nbar_extendmsg_btn{font-size:<?php echo $nbar['extendMesgLinkFont']; ?>px;color:<?php echo $nbar['extendMesgLinkColor']; ?>;background:<?php echo $nbar['extendMesgLinkBgcolor']; ?>}
#notificationbar .nbar_extendmsg .nbar_extendmsg_img{width:<?php echo $nbar['extendMesgImgWidth']; ?>px;height:<?php echo $nbar['extendMesgImgHeight']; ?>px;border-width:<?php echo $nbar['extendMesgImgBorder']; ?>px;border-color:<?php echo $nbar['extendMesgImgBorderCol']; ?>;}
#notificationbar .nbar_extendmsg .nbar_exmsg{<?php if(isset($nbar['extendMesgWrapWt']) && $nbar['extendMesgWrapWt']!=""){ echo 'width:'.$nbar['extendMesgWrapWt'].'px';} ?>}
<?php if($nbar['defaultposition'] =="bottom"){ ?> 
#notificationbar a.nbar_close{background-image:url("<?php echo plugins_url('',dirname(__FILE__)); ?>/images/sprite_bot.png");background-position:0 center;}
#notificationbar a.nbar_close:hover{background-position:0 center;opacity:0.6;filter:alpha(opacity = 60);}
<?php } ?>
</style>
<?php
}

// add HTML to the corresponding notification bar
function nbar_addHTML($nbar_option){
global $post;
$nbar_getOptHtml = get_option($nbar_option);
$nbarH = $nbar_getOptHtml;

$nb_message     = (isset($nbarH['message'])) ? $nbarH['message'] : 0;
$nb_linkText    = (isset($nbarH['linkText'])) ? $nbarH['linkText'] : 0;
$nb_linkUrl     = (isset($nbarH['linkText'])) ? $nbarH['linkUrl'] : '#';
$nb_facebookUrl = (isset($nbarH['facebookUrl'])) ? $nbarH['facebookUrl'] : 0;
$nb_twitterUrl  = (isset($nbarH['twitterUrl'])) ? $nbarH['twitterUrl'] : 0;
$nb_linkedinUrl = (isset($nbarH['linkedinUrl'])) ? $nbarH['linkedinUrl'] : 0;
$nb_googleUrl   = (isset($nbarH['googleUrl'])) ? $nbarH['googleUrl'] : 0;
$nb_rssUrl      = (isset($nbarH['rssUrl'])) ? $nbarH['rssUrl'] : 0;
$nb_extendMesg  = (isset($nbarH['extendMesg'])) ? $nbarH['extendMesg'] : 0;
$nb_extendMesgShow = (isset($nbarH['extendMesgShow'])) ? $nbarH['extendMesgShow'] : 'template';
$nb_extendMesgImg = (isset($nbarH['extendMesgImg'])) ? $nbarH['extendMesgImg'] : 0;
$nb_extendMesgText = (isset($nbarH['extendMesgText'])) ? $nbarH['extendMesgText'] : 0;
$nb_extendMesgLinkUrl  = (isset($nbarH['extendMesgLinkUrl'])) ? $nbarH['extendMesgLinkUrl'] : '#';
$nb_extendMesgLinkText = (isset($nbarH['extendMesgLinkText'])) ? $nbarH['extendMesgLinkText'] : 0;


?>
<div id="notificationbar" class="<?php echo $nbar_option; ?>">
	<a class="nbar_downArr" href="#nbar_downArr" style="display:none;"></a>
	<div class="nbar_wrapper">
		<div class="nbar_topwrap">
			<?php if($nb_message){ ?><div class="nbar_msg nbar_topitem"><?php echo stripslashes($nb_message); ?></div><?php } ?>
			<?php if($nb_linkText){ ?> <a class="nbar_button nbar_topitem" href="<?php echo $nb_linkUrl; ?>" target="<?php echo $nbarH['linkTarget']; ?>"><?php echo stripslashes($nb_linkText); ?></a><?php } ?>
			<div class="nbar_sociallinks">
				<?php if($nb_facebookUrl){ ?><a href="<?php echo $nb_facebookUrl; ?>" class="fb" title="facebook" target="_blank" ></a><?php } ?>
				<?php if($nb_twitterUrl){ ?><a href="<?php echo $nb_twitterUrl; ?>" class="tw" title="twitter"  target="_blank" ></a><?php } ?>
				<?php if($nb_linkedinUrl){ ?><a href="<?php echo $nb_linkedinUrl; ?>" class="ld" title="linkedin" target="_blank" ></a><?php } ?>
				<?php if($nb_googleUrl){ ?><a href="<?php echo $nb_googleUrl; ?>" class="gp" title="google+" target="_blank" ></a><?php } ?>
				<?php if($nb_rssUrl){ ?><a href="<?php echo $nb_rssUrl; ?>" class="rss" title="rss"  target="_blank" ></a><?php } ?>
				<?php if($nbarH['facebookLike']=='yes'){ ?><iframe class="fblike" src="http://www.facebook.com/plugins/like.php?href=<?php echo urlencode(get_permalink($post->ID)); ?>&amp;layout=button_count&amp;show_faces=false&amp;width=60&amp;action=like&amp;font=segoe+ui&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0" allowTransparency="true"></iframe><?php } ?>
			</div>
			<?php if($nb_extendMesg){ ?><a href="JavaScript:void(0);" title="<?php _e('show/hide','nbar'); ?>" class="nbar_plusminus"></a><?php } ?>
			<a href="JavaScript:void(0);" title="close" class="nbar_close"></a>
		</div>
		<?php if($nb_extendMesg){ ?>
		<div class="nbar_extendmsg <?php echo $nbarH['extendMesgTemplate']; ?>">
			<div class="nbar_exmsg">
				<?php 
				if($nb_extendMesgShow ==='sidebar' && isset($nb_extendMesgShow) && $nb_extendMesgShow!="") { 
					?>
					<div class="nbar_sidebar">
						<?php if ( !function_exists('dynamic_sidebar')|| !dynamic_sidebar('Notification Bar Pro Widget Area')) : endif; ?>
						<div style="clear:both;"></div>
					</div>
					<?php
				}
				else{
					?>	
					<?php if($nb_extendMesgImg){ ?><img src="<?php echo $nb_extendMesgImg; ?>" class="nbar_extendmsg_img" /><?php } ?>
					<div class="nbar_extendmsg_wrap">
						<?php if($nb_extendMesgText){ ?><div class="nbar_extendmsg_txt"><?php echo do_shortcode(stripslashes($nb_extendMesgText)); ?></div><?php } ?>
						<?php if($nb_extendMesgLinkText){ ?><a href="<?php echo $nb_extendMesgLinkUrl; ?>" target="<?php echo $nbarH['extendMesgLinkTarget']; ?>" class="nbar_extendmsg_btn"><?php echo stripslashes($nb_extendMesgLinkText); ?></a><?php } ?>
					</div>
					<?php 
				} 
				?>
				<div style="clear:both;"></div>
			</div>
		</div>
		<?php } ?>
	</div>
	<div class="nbar_shadow"></div>
</div>
<a id="nbar_downArr" href="JavaScript:void(0);" ></a>
<?php
}

// call notificationbar jQuery function
function nbar_calljQfunc($nbar_option){
$nbar_getOpts = get_option($nbar_option);
$nbar_opts = $nbar_getOpts;
$nbar_stayTime = $nbar_opts['stayTime']*1000;
$nbar_exmsgOpnDur = $nbar_opts['extMesgOpenTime']*1000;
$nbar_exmsgClosDur = $nbar_opts['extMesgCloseTime']*1000;
if($nbar_stayTime=="" || $nbar_stayTime==0){$nbar_stayTime=10000;}
if($nbar_exmsgOpnDur=="" || $nbar_exmsgOpnDur==0){$nbar_exmsgOpnDur=4000;}
if($nbar_exmsgClosDur=="" || $nbar_exmsgClosDur==0){$nbar_exmsgClosDur=4000;}
?>
<script type="text/javascript">
	jQuery(document).ready(function(){
	
		<?php 
		if($nbar_opts['defaultposition'] =="bottom"){ ?>jQuery('body').append('<div class="notification_push"></div>');<?php } 
		else{ ?>jQuery('body').prepend('<div class="notification_push"></div>');<?php } ?>
		
		jQuery("#notificationbar").notificationbar({
		'defaultstate': '<?php echo $nbar_opts['defaultState']; ?>',
		'staytime': '<?php echo $nbar_stayTime; ?>',
		'exmsgstate': '<?php echo $nbar_opts['extendMesgState']; ?>',
		'exmsgopentm':'<?php echo $nbar_exmsgOpnDur; ?>',
		'exmsgclosetm':'<?php echo $nbar_exmsgClosDur; ?>',
		'disablecmsg':'<?php echo $nbar_opts['extendMesgCmsg']; ?>'
		});
	});
</script>
<!-- Notification Bar PRO Ends Here -->
<?php
}

function nbar_getnbarName($nbarID){
	global $wpdb;
	$table_name = $wpdb->prefix . "notificationbar"; 
	$nbar_fetchnbar = $wpdb->get_results("SELECT * FROM $table_name WHERE id=$nbarID",ARRAY_A);
	$nbar_optionNm = $nbar_fetchnbar[0]['option_name'];
	return $nbar_optionNm;
}

function nbar_isActive($nbarID){
	global $wpdb;
	$table_name = $wpdb->prefix . "notificationbar"; 
	$nbar_fetchnbar = $wpdb->get_results("SELECT * FROM $table_name WHERE id=$nbarID",ARRAY_A);
	$nbar_active = $nbar_fetchnbar[0]['active'];
	return $nbar_active;
}
?>