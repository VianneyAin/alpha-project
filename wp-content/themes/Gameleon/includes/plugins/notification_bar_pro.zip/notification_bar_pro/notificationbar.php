<?php
/*
Plugin Name:Notification Bar PRO
Plugin URI: http://www.wpfruits.com
Description: This plugin will show notification at top of the header.
Author: Wpfruits
Version: 2.0.9
Author URI: http://www.wpfruits.com
*/
//----------------------------------------------------------------------------------
/*---Load Required Files------------------------------
----------------------------------------------------*/
include_once('inc/admin/nbarups.php');
include_once('scripts.php');
include_once('inc/admin/nb_admin-options.php');
define('NBARPROPLUGIN_URL', plugin_dir_url(__FILE__));
//---------------------------------------------------

//This function will create new database fields with default values
function nbar_defaults(){
	    $default = array(
		'defaultposition' => 'top',
		'defaultState' => 'open',
		'stayTime' => '10',
		'colorScheme' => '#b10d13',
        'message' => 'Get my Subscription',
		'messageFont' => '12',
    	'messageColor' => '#f3eeee',
		'linkUrl'=> 'http://www.wpfruits.com',
    	'linkText' => 'Click here',
		'linkFont' => '12',
		'linkTextColor' => '#fbf8e6',
		'linkBgcolor' => '#57380b',
		'linkTarget' => '_blank',
		'facebookUrl'=> 'http://www.wpfruits.com',
		'twitterUrl'=> 'http://www.wpfruits.com',
		'linkedinUrl'=> 'http://www.wpfruits.com',
		'googleUrl'=> 'http://www.wpfruits.com',
		'rssUrl'=> 'http://www.wpfruits.com',
		'facebookLike'=> 'yes',
		'extendMesg' => 'true',
		'extendMesgWrapWt' => '960',
		'extendMesgShow'=>'template',
		'extendMesgState' => 'open',
		'extendMesgCmsg' => 'no',
		'extMesgOpenTime' => '4',
		'extMesgCloseTime' => '4',
		'extendMesgTemplate' => 'template-3',
		'extendMesgText' => 'Extend Message goes here..',
		'extendMesgFont' => '12',
		'extendMesgColor' => '#ffffff',
		'extendMesgImg' => plugins_url('inc/images/default.jpg',__FILE__),
		'extendMesgImgWidth' => '150',
		'extendMesgImgHeight' => '150',
		'extendMesgImgBorder' => '2',
		'extendMesgImgBorderCol' => '#fff',
		'extendMesgLinkUrl'=> 'http://www.wpfruits.com',
		'extendMesgLinkText' => 'More..',
		'extendMesgLinkFont' => '12',
		'extendMesgLinkColor' => '#fde8c0',
		'extendMesgLinkBgcolor' => '#62562e',
		'extendMesgLinkTarget' => '_blank'
    );
return $default;
}

function nbar_settings(){
	    $defaultSettings = array(
		'nbar_settingchk' => 'true',
		'nbar_setDfltnbar' => '1',
		'nbar_setPages' => 'true',
		'nbar_setPosts' => 'true',
		'nbar_setHomepage' => 'true',
		'nbar_setBlogpage' => 'true',
		'nbar_setcats' => 'true',
		'nbar_setctax' => 'true',
		'nbar_settags' => 'true',
		'nbar_setdate' => 'true',
		'nbar_setauthor' => 'true'
    );
return $defaultSettings;
}

add_action('admin_menu', 'nbar_plugin_admin_menu');
function nbar_plugin_admin_menu() {
	add_menu_page('Add Notification Bar', 'Notification Bar Pro', 'publish_posts', 'notificationbar','add_notification_bar',plugins_url('inc/images/icon.png',__FILE__));
	add_submenu_page('notificationbar', 'Edit Notification Bar', '', 'publish_posts','nbar_edit','edit_notification_bar');
}

// Runs when plugin is activated and creates new database field
register_activation_hook(__FILE__,'notificationbar_plugin_install');
function notificationbar_plugin_install() {
    add_option('notificationbar_options', nbar_defaults());
    add_option('notificationbar_settings', nbar_settings());
    nbar_install();
    global $wpdb;
	$table_name = $wpdb->prefix . "notificationbar"; 
    $sql = "INSERT INTO " . $table_name . " values ('','notificationbar_options','1');";
    $wpdb->query( $sql );
}

//notification bar Table
function nbar_install(){
    global $wpdb;
	$table_name = $wpdb->prefix . "notificationbar"; 
		$sql = "CREATE TABLE " . $table_name . " (
		  id mediumint(9) NOT NULL AUTO_INCREMENT,
		  option_name VARCHAR(255) NOT NULL DEFAULT  'notificationbar_options',
		  active tinyint(1) NOT NULL DEFAULT  '0',
		  PRIMARY KEY (`id`),
          UNIQUE (
                    `option_name`
            )
		)";
		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
}

// get notificationbar version
function nbar_get_version(){
	if ( ! function_exists( 'get_plugins' ) )
	require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
	$plugin_folder = get_plugins( '/' . plugin_basename( dirname( __FILE__ ) ) );
	$plugin_file = basename( ( __FILE__ ) );
	return $plugin_folder[$plugin_file]['Version'];
}

add_action('wp_ajax_nbpro_saved' ,'nbpro_edit_saved');
function nbpro_edit_saved(){
	check_ajax_referer('nbpro-options-data', 'security');
	$data = $_POST;
	unset($data['security'], $data['action']);
	$nbar_itemnameopt = $data['nbar_itemname'];
	$data_arr = $data[$nbar_itemnameopt];
	
	if(update_option($nbar_itemnameopt, $data_arr)){
		die('1');
	} else {
		die('0');
	}
}

// add notification bar on frontend 
function nbar_addon_front(){
	include_once('inc/front/nb_front.php');
}
add_action('wp_footer','nbar_addon_front');

// add notification extend click shortcode
function nbar_extclick_shortcode( $atts, $content="" ) {
     return "<span class='nbar_extclick_shortcode'>$content</span>";
}
add_shortcode( 'nbarExtclick', 'nbar_extclick_shortcode' );

// regsiter notification bar sidebar
function nbar_widget_init() {
	register_sidebar(array(
		'name' => 'Notification Bar Pro Widget Area',
		'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>'
	));
}
add_action( 'init', 'nbar_widget_init' );
//----------------------------------------------------------------------------------